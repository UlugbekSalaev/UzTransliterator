from .UzTransliterator import UzTransliterator
from .Data import Mapping