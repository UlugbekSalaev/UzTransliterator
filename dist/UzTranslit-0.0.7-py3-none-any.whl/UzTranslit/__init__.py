from .UzTranslit import UzTranslit
from .Data import Mapping